
function page(page){
  window.location="/"+page;
}
function opeen(website){
  window.location=website;
}
